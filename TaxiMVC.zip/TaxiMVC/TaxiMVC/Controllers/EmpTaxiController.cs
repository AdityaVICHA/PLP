﻿using TaxiMVC.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.Linq;

namespace TaxiMVC.Controllers
{
    public class EmpTaxiController : Controller
    {
        //connect with ado entity model
        PLPEntities1 db = new PLPEntities1();
        string Baseurl = "http://localhost:55703/";
        static user obj = new user();

        //open login page

        public ActionResult Login()
        {
            return View("Login", "~/Views/Shared/_LoginLayout.cshtml");
        }
        
        //check credentials of user
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(user objUser)
        {
            if (ModelState.IsValid)
            {
                obj = db.users.Where(a => a.user_id.Equals(objUser.user_id) && a.user_password.Equals(objUser.user_password)).FirstOrDefault();
                if (obj != null)
                {
                    Session["user_id"] = obj.user_id;
                    //Session["user_name"] = obj.user_name.ToString();

                    if (obj.user_role == 1)
                        return RedirectToAction("EmpIndex");
                    else if (obj.user_role == 2)
                        return RedirectToAction("CustomerBooking");
                    else
                        return RedirectToAction("Login");
                }


            }
            return View("Login", "~/Views/Shared/_LoginLayout.cshtml", objUser);
        }

        
        private employee empInfo;

        //get all pending booking of the user
        public async Task<ActionResult> EmpIndex()
        {
            List<booking> EmpInfo = new List<booking>();
           
            using (var client = new HttpClient())
            {
                //Passing service base url  
               
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();
                //Define request data format  
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                HttpResponseMessage Res = await client.GetAsync("api/Employee/GetAllBookings?id=1000");

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var EmpResponse = Res.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the Employee list  
                    EmpInfo = JsonConvert.DeserializeObject<List<booking>>(EmpResponse);

                }
                //returning the employee list to view  
                return View(EmpInfo);
            }
        }


        //get all logs of the employee
        public async Task<ActionResult> Logs()
        {
            List<booking> EmpInfo = new List<booking>();

            using (var client = new HttpClient())
            {
                obj.user_id = 1000;
                //Passing service base url  

                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();
                //Define request data format  
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                HttpResponseMessage Res = await client.GetAsync("api/Employee/GetLogs?id="+obj.user_id.ToString());

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var EmpResponse = Res.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the Employee list  
                    EmpInfo = JsonConvert.DeserializeObject<List<booking>>(EmpResponse);

                }
                //returning the employee list to view  
                return View(EmpInfo);
            }
        }


        //get all the rooster details of employee
        public async Task<ActionResult> EmpRoster()
        {
            List<employee_roster> empRoster = new List<employee_roster>();
           

            using (var client = new HttpClient())
            {
                //Passing service base url  
               
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();
                //Define request data format  
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                HttpResponseMessage Res = await client.GetAsync("api/Employee/GetRosters?id=1000");

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var EmpResponse = Res.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the Employee list  
                   empRoster= JsonConvert.DeserializeObject<List<employee_roster>>(EmpResponse);

                }
                //returning the employee list to view  
                return View(empRoster);
            }
        }

        //get information of employee from DB
        public async Task<ActionResult> EmpProfile()
        {
           
            employee emp = new employee();

            using (var client = new HttpClient())
            {
                //Passing service base url  

                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();
                //Define request data format  
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                HttpResponseMessage Res = await client.GetAsync("api/Employee/GetProfile?id=1000");

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var EmpResponse = Res.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the Employee list  
                    emp = JsonConvert.DeserializeObject<employee>(EmpResponse);

                }
                //returning the employee list to view  
                return View(emp);
            }
        }

        //Edit Employee details and post it in the DB
        public async Task<ActionResult> MyEmpProfile()
            {
            using (var client = new HttpClient())
            {
                obj.user_id = 1001;
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage Res = await client.GetAsync("api/Employee/GetEmpProfile?id="+obj.user_id.ToString());


                if (Res.IsSuccessStatusCode)
                {
                    var UserResponse = Res.Content.ReadAsStringAsync().Result;


                    empInfo = JsonConvert.DeserializeObject<employee>(UserResponse);
                }

                return View(empInfo);
            }
        }
        [HttpPost]
        public async Task<ActionResult> MyEmpProfile(employee emp)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                
                emp.employee_id = obj.user_id;
                HttpResponseMessage Res = await client.PostAsJsonAsync<employee>("api/Employee/PostEmpProfile", emp);
                return View();
            }
        }

        public async Task<ActionResult> Availability()
        {
            using (var client = new HttpClient())
            {
                obj.user_id = 1001;
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage Res = await client.GetAsync("api/Employee/GetAvailability?id=" + obj.user_id.ToString());


                if (Res.IsSuccessStatusCode)
                {
                    var UserResponse = Res.Content.ReadAsStringAsync().Result;


                    empInfo = JsonConvert.DeserializeObject<employee>(UserResponse);
                }

                return View(empInfo);
            }
        }
        [HttpPost]
        public async Task<ActionResult> Availability(employee emp)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                emp.employee_id = obj.user_id;
                HttpResponseMessage Res = await client.PostAsJsonAsync<employee>("api/Employee/PostAvailability1", emp);
                return View();
            }
        }
    }
}