﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Employee.Models;
using System.Data.Entity;

namespace Employee.Controllers
{
   //
    public class EmployeeController : ApiController
    {
        // Functionalities for Checking online bookings
        PLPEntities db = new  PLPEntities();

        public IEnumerable<employee_roster> GetRosters(int id)
        {
           

            return db.employee_roster.Where(e => e.employee_id == id).ToList();
        }

        public IEnumerable<booking> GetLogs(int id)
        {


            return db.bookings.Where(e => e.employee_id == id).ToList();
        }

        public IEnumerable<booking> GetAllBookings(int id)
        {
           
            return db.bookings.Where(e => e.employee_id == id).ToList();
        }
        
        public employee GetEmpProfile(int? id)
        {
            
            employee emp = db.employees.Where(e => e.employee_id == id).Single();
            return emp;
        }

        
        public void PostEmpProfile([FromBody()]employee employee)
        {
            try
            {
                db.Entry(employee).State = EntityState.Modified;
                db.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }
      
        //[HttpGet]
        //public employee Availability(bool avail, int id)
        //{

        //    employee emp = db.employees.FirstOrDefault();

        //    emp.available = avail;
        //    try
        //    {
        //        db.Entry(emp).State = EntityState.Modified;
        //        db.SaveChanges();
        //    }
        //    catch(Exception e)
        //    {
        //        Console.WriteLine(e.Message);
        //    }

        //    return db.employees.FirstOrDefault();

        //}

       

        [HttpGet]
        public IHttpActionResult Delete(int id)
        {
            if (id <= 0)
                return BadRequest("Not a valid student id");

            try
            {
                var log = db.employee_log
                    .Where(e => e.log_id == id)
                    .FirstOrDefault();

                db.Entry(log).State = EntityState.Deleted;
                db.SaveChanges();
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return Ok();
        }

    }
}
